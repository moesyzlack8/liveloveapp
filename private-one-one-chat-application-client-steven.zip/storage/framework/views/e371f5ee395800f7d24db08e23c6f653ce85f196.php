<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
      <chat-component></chat-component>
      <user-component></user-component>
    </div>
</div>
  <br />
  <div class="parallax" id="parallax">
      <div id="homePageContainer"><!--home page container-->
      <div class="jumbotron">
          <div class="jumbotron text-">
            <h3 style="color: white;">Kick Back.. Feet Up. </h3>
            <h1 class="display-1" style="color: white;">And.. Relax....<h1>
            <p><a  class="btn btn-primary btn-lg" href="/login" role="button">Login</a> <a class="btn btn-success btn-lg" href="/register" role="button">Register</a></p>
          </div>
        </div>
        <div class="jumbtron" id="headIcon">
          
            <div class="homeArrow"><a href="#iPSec"><i class="fas fa-angle-double-down fa-2x" ></a></i></div>
        </div>
  </div><!--top ends-->
  </div>
  <div id="iPSec">
      <h1 class="display-3 text-center" id="iPSecTitle">What you've got</h1>
      <div class="container marketing">
          <div class="row text-center" id="iPsecRow">
            <div class="col-lg-4">
                <div class="rounded-circle" alt="Keyboard Icon"><i class="fas fa-info-circle fa-7x" id="iPSecIcons"></i></div>
                <h2>Information</h2>
              <p>Donec sed odio dui. Etiam porta sem malesuada magna mollis euismod. Nullam id dolor id nibh ultricies vehicula ut id elit. Morbi leo risus, porta ac consectetur ac, vestibulum at eros. Praesent commodo cursus magna.</p>
              <p><a class="btn btn-secondary" href="#mindfullness-page" role="button">View details &raquo;</a></p>
            </div><!-- /.col-lg-4 -->
            <div class="col-lg-4">
              <div class="rounded-circle" alt="Keyboard Icon"><i class="far fa-address-card fa-7x" id="iPSecIcons"></i></div>
              <h2>Public Blog</h2>
              <p>Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit. Cras mattis consectetur purus sit amet fermentum. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh.</p>
              <p><a class="btn btn-secondary" href="/posts" role="button">View details &raquo;</a></p>
            </div><!-- /.col-lg-4 -->
            <div class="col-lg-4">
              <div class="rounded-circle" alt="Chat Icon" ><i class="far fa-comments fa-7x" id="iPSecIcons"></i></div>
                <h2>Private Live Chat</h2>
              <p>Donec sed odio dui. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Vestibulum id ligula porta felis euismod semper. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus.</p>
              <p><a class="btn btn-secondary" href="/chat" role="button">View details &raquo;</a></p>
            </div><!-- /.col-lg-4 -->
          </div><!-- /.row -->
        </div><!--Container marketing ends-->
  </div><!--iPSec ends-->
  <div id="aPSec">
      <div id="about-page">     
      </div>
  </div>
  <div id="aPSec">
      <div id="about-page">

    </div><!--about-page ends-->
  </div><!--aPSec ends-->
  <div id="mFSec">
    <div id="mindfullness-page">
      <div class="accordion text-justify" id="accordionExample">
          <div class="card">
            <div class="card-header" id="headingOne">
              <h5 class="mb-0">
                <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                  Mindfullness
                </button>
              </h5>
            </div>
            <div id="collapseOne" class="collapse hide" aria-labelledby="headingOne" data-parent="#accordionExample">
              <div class="card-body">
                      <div id="feelGoodBody">
                              <div class="box"></div>
                              <div class="box"></div>
                              <div class="box"></div>
                      </div>
                Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
              </div>
            </div>
          </div>
          <div class="card">
            <div class="card-header" id="headingTwo">
              <h5 class="mb-0">
                <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                  Meditation
                </button>
              </h5>
            </div>
            <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
              <div class="card-body">
                Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
              </div>
            </div>
          </div>
          <div class="card">
            <div class="card-header" id="headingThree">
              <h5 class="mb-0">
                <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                  Therapy
                </button>
              </h5>
            </div>
            <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
              <div class="card-body">
                Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
              </div>
            </div>
          </div>
        </div>
      </div><!--accordian ends-->
  </div><!--services ends-->
  </div><!--#mindfullness-page ends-->
  </div><!--sPSec ends-->
  <footer>
      <p class="lead mb-0" style="color:white">Web Based Application for people who suffer from mental health &copy;<a href="http://stevenmaughan.com" target = blank>Steven Maughan</a></p><br />

  </footer>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>