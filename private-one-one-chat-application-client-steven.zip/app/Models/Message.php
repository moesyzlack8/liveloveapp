<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Message extends Model
{
    public function chats()
    {
        //every message can have many chats in this case two for one to one private chat
        return $this->hasMany(Chat::class);
    }
}
