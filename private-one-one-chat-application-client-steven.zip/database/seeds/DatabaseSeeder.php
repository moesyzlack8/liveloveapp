<?php

use Illuminate\Database\Seeder;
use App\User;//to give fake users

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        // $this->call(UsersTableSeeder::class);
        //seed fake users into the database for testing after every migration
        factory(User::class)->create(
            [
                'email' => 'steven@test.com',
                'name' => 'Steven'
               
            ]
        );
        factory(User::class)->create(
            [
                'email' => 'moe@test.com',
                'name' => 'Moe'
                
            ]
        );
        factory(User::class)->create(
            [
                'email' => 'syzlack@test.com',
                'name' => 'Syzlack'
               
            ]
        );
    }
}
