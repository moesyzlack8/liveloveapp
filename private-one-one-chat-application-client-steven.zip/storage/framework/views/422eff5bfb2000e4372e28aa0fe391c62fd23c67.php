<?php $__env->startSection('content'); ?>
<div id="wall-posts">
    <h1>Wall Posts</h1>
    <?php if(count($posts) > 0): ?>
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card card-body bg-light">
                <div class="row">
                    <div class="col-md-4 col-sm-4">
                    <img style="width:100%" src="/storage/post_images/<?php echo e($post->post_image); ?>"><!--SHOWS THE IMAGE THE USER POSTED-->
                    <br><br>
                    </div>
                    
                    <div class="col-md-8 col-sm-8">
                        <h3><a href="/posts/<?php echo e($post->id); ?>"><?php echo e($post->title); ?></a></h3>
                        <small>Posted on <?php echo e($post->created_at); ?> by <?php echo e($post->user->name); ?></small><!--shows when the post was posted-->
                    </div>

                </div>
            </div>
            <br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($posts->links()); ?><!--//part of elequent fetches the data in decending order only shows 10 posts per page-->
    <?php else: ?>
        <p>No Posts found</p>
    <?php endif; ?>
</div><!--wall-posts end-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>