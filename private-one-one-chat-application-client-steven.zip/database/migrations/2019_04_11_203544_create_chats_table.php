<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateChatsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('chats', function (Blueprint $table) {
            $table->increments('id');
            $table->unsignedInteger('message_id');//connects to messages table
            $table->unsignedInteger('session_id');//connects to session table
            $table->unsignedInteger('user_id');//chat is sent by the user
            $table->boolean('type');//0 is for send and 1 is for recieve. whichever user sends the message the type will be 0 and whoever recieves the message the type will be 1
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('chats');
    }
}
