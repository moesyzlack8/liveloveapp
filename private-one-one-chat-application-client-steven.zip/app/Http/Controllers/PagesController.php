<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PagesController extends Controller
{
    public function index(){
        $title = 'Welcome to Live & Love :)';
        //return view('pages.index', compact('title'));
        return view('pages.index')->with('title', $title);
    }

    public function about(){
        $title = 'About Us :)';
        return view('pages.about')->with('title', $title);
    }

    public function info(){
        $data = array(//associative array which means it passes in key value pairs
                'title' => 'Services',
                'info' => ['Meditation', 'Mental Health', 'Feel Good']
        );
        return view('pages.info')->with($data);
    }

    public function chat(){
        $title = 'Chat Page';
        return view('pages.chat')->with('title', $title);
    }
}
