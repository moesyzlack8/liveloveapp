<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use App\Post;//brings in post
use DB;//the DataBase library

class PostsController extends Controller
{
        /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //we want this to show the wall even when your not logged in
        //so we add exceptions in the auth middleware
        //pass in an array called except and point it to an array of excepted views
        $this->middleware('auth', ['except' => ['index', 'show']]);
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //$posts = Post::all();//part of elequent fetches all of the data in the table
        //return Post::where('title', 'Post Two')->get();//part of elequent get individual post by title
        //$posts = DB::select('SELECT * FROM posts');//using DB queries
        //$posts = Post::orderBy('title', 'desc')->get();//part of elequent fetches the data in order and the most recent is at the top
        //$posts = Post::orderBy('title', 'desc')->take(1)->get();//part of elequent takes the most recent post and only shows that

        $posts = Post::orderBy('created_at', 'desc')->paginate(10);//part of elequent fetches the data in decending order only shows 10 posts per page
        return view('posts.index')->with('posts', $posts);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('posts.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this -> validate($request, [
            'title' => 'required',
            'body' => 'required',
            //ADD VALIDATION FOR IMAGE
            'post_image' => 'image|nullable|max:1999'//makes sure its an image no bigger than 2mb
        ]);

        //Handle File Upload
        if($request -> hasFile('post_image')){//if the user clicks choose file and uploads
            //get the filename with the extension
            $filenameWithExt = $request->file('post_image')->getClientOriginalName();
            
            //just get the file name
            $filename = pathinfo($filenameWithExt, PATHINFO_FILENAME);
            
            //just get the extension
            $extension = $request->file('post_image')->getClientOriginalExtension();
            
            //store the filename
            //calls the original filename  underscaore and then a timestamp which makes the filename unique
            //so if someone uploads with the same name it wont overwrite anything
            $fileNameToStore = $filename.'_'.time().'.'.$extension;
            //upload the image
            //runs a simlink from the storage/app/public folder to the public folder
            //then its going to create a storage folder within the public folder
            //so that it is accessible from the browser
            //terminal -> $ php artisan storage:link
            $path = $request->file('post_image')->storeAs('public/post_images', $fileNameToStore);
        }else{
            $fileNameToStore = 'noimage.jpg';//if the user doesnt upload an image then it will look at this default image and use this image post
        }
        //validates the form and passes in the request

        //Create Post
        $post = new Post;
        //add fields
        $post->title = $request->input('title');
        $post->body = $request->input('body');
        $post->user_id = auth()->user()->id;
        $post->post_image = $fileNameToStore;
        $post->save();

        return redirect('/posts')->with('success', 'Post Created');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $post = Post::find($id);//returns a single post
        return view('posts.show')->with('post', $post);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     *
     */
    public function edit($id)
    {
        
        $post = Post::find($id);//check the user id
        
        //check for the correct user so another user cannot edit your post from the address bar
        if(auth()->user()->id !==$post->user_id){
            return redirect('/posts')->with('error', 'Unauthorized User');
        }
        return view('posts.edit')->with('post', $post);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this -> validate($request, [
            'title' => 'required',
            'body' => 'required'
        ]);

        //Handle File Upload
        if($request -> hasFile('post_image')){//if the user clicks choose file and uploads
            //get the filename with the extension
            $filenameWithExt = $request->file('post_image')->getClientOriginalName();
            
            //just get the file name
            $filename = pathinfo($filenameWithExt, PATHINFO_FILENAME);
            
            //just get the extension
            $extension = $request->file('post_image')->getClientOriginalExtension();
            
            //store the filename
            //calls the original filename  underscaore and then a timestamp which makes the filename unique
            //so if someone uploads with the same name it wont overwrite anything
            $fileNameToStore = $filename.'_'.time().'.'.$extension;
            //upload the image
            //runs a simlink from the storage/app/public folder to the public folder
            //then its going to create a storage folder within the public folder
            //so that it is accessible from the browser
            //terminal -> $ php artisan storage:link
            $path = $request->file('post_image')->storeAs('public/post_images', $fileNameToStore);
        }

        //Create Post
        $post = Post::find($id);
        //add fields
        $post->title = $request->input('title');
        $post->body = $request->input('body');
        if($request->hasFile('post_image')){
            //noimage.jpg file won't get deleted in case the user creates a post
            // without an image and then decides to edit it by adding one.
            if($post->post_image != 'noimage.jpg') {
                Storage::delete('public/post_images/' . $post->post_image);
            }
            $post->post_image = $fileNameToStore;
        }
        $post->save();

        return redirect('/posts')->with('success', 'Post Updated');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $post = Post::find($id);// check the user id

        //check for the correct user so another user cannot delete your post from the address bar
        if(auth()->user()->id !==$post->user_id){
            return redirect('/posts')->with('error', 'Unauthorized User');
        }

        if($post->post_image != 'noimage.jpg'){
            //delete the image if the post image is NOT equal to 
            Storage::delete('public/post_images/'.$post->post_image);
        }
        $post ->delete();
        return redirect('/posts')->with('success', 'Post Removed');

    }
}
