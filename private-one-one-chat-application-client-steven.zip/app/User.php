<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    //create a relationship between the user and the posts
    //1 to many relationship as the user has many posts
    public function posts(){
        return $this->hasMany('App\Post');
    }

    //create a relationship between the user and messages
    // 1 to many as the user has many messages and the messages belongs to the user
    public function messages()
        {
            return $this->hasMany(Message::class);
        }
}
