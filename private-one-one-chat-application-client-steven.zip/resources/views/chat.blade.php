@extends('layouts.app')

@section('content')
<div class="container" id="chatApp">
        <chat-component></chat-component>

    </div>
</div>
@endsection