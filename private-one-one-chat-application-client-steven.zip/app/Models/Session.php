<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Session extends Model
{
    protected $guarded =[];//does not guard anything specifically it will just accept anything that is giving and try to fill the table
    //create a relationship between session messages and chat
    //grab all the chats related to session via the message
    //session has many chats, every chat is related to a message
    public function chats()

    {
        return $this->hasManyThrough(Chat::class,Message::class);
    }

    public function messages()
    
    {
        return $this->hasMany(Message::class);
    }

}
