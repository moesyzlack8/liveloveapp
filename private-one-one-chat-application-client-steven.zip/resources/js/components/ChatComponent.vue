<template>
 <div class="row justify-content-center">
    <div class="col-md-3">
        <div class="card">
            <div class="card-header">
                Users
            </div>
            <!--prevent href default and loops the contacts through the li tag-->
            <!--only show chat-box when session is started after the user name has been clicked-->
            <!--looks for a contact within contacts then shows the contacts name-->
            <ul class="list-group">
                <li class="list-group-item"
                @click.prevent="openChat(contact)"
                :key=contact.id
                v-for="contact in contacts">
                    <a href="">{{contact.name}}</a>
                    <i class="fa fa-circle float-right text-success" v-if="contact.online" aria-hidden="true"></i><!--only show green when user is online-->
                </li>
               
            </ul>
        </div>
    </div>
    <div class="col-9">
        <span v-for="contact in contacts" :key="contact.id" v-if="contact.session"><!--only if the contact session is open loop through contacts-->
            <!--box will only show if contact.session.open = true-->
            <!--when a close event occurs go to the close function-->
            <!--show user name in chat-box header-->
            <!--contact box will close when clicked @close="close(contact)" -->
            <message-component
            v-if="contact.session.open"
            @close="close(contact)"
            :contact = contact 
            ></message-component>
        </span>
    </div>
</div>
</template>

<script>
    import MessageComponent from './MessageComponent';//import the child component MessageComponent
    export default {
        data(){
            return {
                 contacts:[]//contacts list array
            }
        },
        methods:{
            close(contact){
                //closes the chat-box when X icon is clicked
                contact.session.open = false
            },

            getContacts(){
              //axios.post('/getContacts').then(res => console.log(res.data.data))//post request to a url for getContacts then contacts[] = response.data. shows all contacts in an array
              axios.post('/getContacts').then(res => this.contacts = res.data.data)//post request to a url for getContacts then contacts[] = response.data.data shows all contacts in an array
            },
            openChat(contact){
                if(contact.session){//check if the user who opened the chat has a session
                    this.contacts.forEach(contact => {//loops through all the contacts
                        contact.session.open = false //before opening a chat-box close all other chat-boxes when a contact is clicked
                    });
                    contact.session.open = true//opens the chat when the user name is clicked

                }else{//otherways create the session for logged in and clicked user

                    this.createSession(contact);
                }

            },
            createSession(contact){//pass contact id into SessionController then create session //after session is created open the session
                axios.post("/session/create", {contact_id: contact.id}).then(res => {
                    (contact.session = res.data.data), (contact.session.open = true);
                });

            },

        },

        created(){
            this.getContacts();//when getContacts is created call this method

            //join the chat broadcasting channel
            Echo.join('Chat')
            .here((users) => {//users are present
            //whenever the user is present loop through the users
                this.contacts.forEach(contact => {
                    users.forEach(user => {
                        if(user.id == contact.id) {
                            contact.online = true
                        }
                    })
                })
            })
            //if the user joined loop through all the contacts, if users id is equal to contact id then do this //otherways do nothing
            .joining((user) => {
                this.contacts.forEach(contact => user.id == contact.id? contact.online = true:'')
             })
            //if the user left loop through all the contacts, if users id is equal to contact id then do this //otherways do nothing
            .leaving((user) => {
                this.contacts.forEach(contact => user.id == contact.id? contact.online = false:'')
            });
        },
        components:{MessageComponent}//components is message component

    }
</script>

 