<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Chat extends Model
{
    //create a chat and message relationship when the session chats are retrieved
    //instead of showing the message id the actual message content is also displayed
    public function message()
    {
         //every chat belongs to a certain message_id
         return $this->belongsTo(Message::class);

    }
}
