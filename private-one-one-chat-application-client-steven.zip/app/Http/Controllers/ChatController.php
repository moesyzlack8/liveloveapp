<?php

namespace App\Http\Controllers;
// bring in UserResource
use App\Http\Resources\UserResource;
//bring in user model
use App\User;

use Illuminate\Http\Request;

class ChatController extends Controller
{
    //define the index() function in ChatController
    public function __construct()
    {
        return $this->middleware('auth');
    }

    public function index()
    {
        //return UserResource::collection(User::all());//shows all user data from the database
        return view('chat');
    }
}
