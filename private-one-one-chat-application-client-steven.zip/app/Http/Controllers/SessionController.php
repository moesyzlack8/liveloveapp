<?php

namespace App\Http\Controllers;
use App\Models\Session;
use Illuminate\Http\Request;
use App\Http\Resources\SessionResource;
use App\Events\SessionEvent;

class SessionController extends Controller
{
    ////create session with users 1 and 2
    //broadcast session.. requries $session, $session_by
    //wrapped session 
    public function create(Request $request)
    {
       $session = Session::create(['user1_id'=>auth()->id(),'user2_id'=>$request->contact_id]);
       
      $modifiedSession = new SessionResource($session);
      broadcast(new SessionEvent($modifiedSession,auth()->id()));
      return $modifiedSession;
    }
}
