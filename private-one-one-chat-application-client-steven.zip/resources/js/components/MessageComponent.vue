<template>
    <div class="card chat-box">
        <div class="card-header">
        <b :class="{'text-danger':user_blocked}"><!--whenever user_blocked = true the font colour changes-->
            {{contact.name}}<!--shows user name in chot-box head-->
            <span v-if="user_blocked">(Blocked)</span><!--if user_blocked = true then show span-->
        </b>
        <!--Close Button-->
        <a href="" @click.prevent="close"><!--prevents the href default then the close function-->
            <i class="fas fa-times float-right"></i>
        </a>
        <!--CloseButtonEnds-->
        <!--OptionsButton-->
        <div class="dropdown float-right mr-4">

            <a href="" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fa fa-ellipsis-v " aria-hidden="true"></i>
            </a>
            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                <a class="dropdown-item" href="#" v-if="user_blocked" @click.prevent="unblock">UnBlock</a><!--if user_blocked = true prevent href default create unblock variable-->
                <a class="dropdown-item" href="#" @click.prevent="block" v-else>Block</a><!--if user_blocked = false prevent href default create block variable-->
                <a class="dropdown-item" href="#" @click.prevent="clear">Clear Chat</a><!--prevent href default create clear variable-->
            </div>
        </div>
        <!--OptionsButtonEnds-->
        </div>
        <div class="card-body" v-chat-scroll>
            <!--Whatever the message is in data(){return {chats:[]}}, will show within the p tag -->
            <p class="card-text" v-for="chat in chats" :key="chat.message">
                {{chat.message}}<!--show the message-->
            </p>
        </div>
        <form class="card-footer"  @submit.prevent="send"><!--Prevent Default with the send method-->
            <div class="form-group">
                    <input type="text" class="form-control" placeholder="Type your message here...."
                    :disabled="user_blocked"><!--whenever user_blocked = true the input field is disabled-->
            </div>
        </form>
    </div>
</template>

<script>
    export default {
        props:['contact'],//sets contact as a prop
        data(){ //data created

            return {
                chats:[],//returns message data in an array
                user_blocked:false//initially user is not blocked
               
            }
        },

        methods:{
            send(){
                console.log('Message Sent???? Ahhh yeahhh')//form is submitting when the user hits enter
            },
            close(){
                  this.$emit('close'); //event for close
            },
            clear(){
                this.chats = []//clears the chat-box when clear dropdown button is clicked
            },
            block(){
                this.user_blocked = true//user is blocked when block dropdown is clicked
            },
            unblock(){
                this.user_blocked = false//user is unblocked when unblock dropdown button is clicked
            }
        },

        created(){// messages below are pushed to chats:[] then looped through v-for="chat in chats" :key="chat.message"
            this.chats.push(
                {message:'Heyy'},
                {message:'How is one?'},
                {message:'How is two?'},
                {message:'How is three?'},
                {message:'How is four?'},
                {message:'How is five?'},
                {message:'How is six?'},
                {message:'How is seven?'},
                {message:'How is eight?'},
                {message:'How is nine?'},
                {message:'How is ten?'},
                {message:'I am at the bottom'},
                )
        },

        mounted() {
            console.log('Component mounted.')
        }
    }
</script>
