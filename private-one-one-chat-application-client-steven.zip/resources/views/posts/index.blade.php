@extends('layouts.app')

@section('content')
<div id="wall-posts">
    <h1>Wall Posts</h1>
    @if(count($posts) > 0)
        @foreach($posts as $post)
            <div class="card card-body bg-light">
                <div class="row">
                    <div class="col-md-4 col-sm-4">
                    <img style="width:100%" src="/storage/post_images/{{$post->post_image}}"><!--SHOWS THE IMAGE THE USER POSTED-->
                    <br><br>
                    </div>
                    
                    <div class="col-md-8 col-sm-8">
                        <h3><a href="/posts/{{$post->id}}">{{$post->title}}</a></h3>
                        <small>Posted on {{$post->created_at}} by {{$post->user->name}}</small><!--shows when the post was posted-->
                    </div>

                </div>
            </div>
            <br>
        @endforeach
        {{$posts->links()}}<!--//part of elequent fetches the data in decending order only shows 10 posts per page-->
    @else
        <p>No Posts found</p>
    @endif
</div><!--wall-posts end-->
@endsection