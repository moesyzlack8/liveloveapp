<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/#

Route::post('getContacts', 'DashboardController@getContacts');//define new getContacts Route from dashboard
Route::post('/session/create', 'SessionController@create');//define new session/create Route from SessionController
Route::get('/', 'PagesController@index');
Route::get('/chat', 'ChatController@index')->name('chat');//define chat route
Route::get('/about', 'PagesController@about');
Route::get('/info', 'PagesController@info');
Route::resource('posts', 'PostsController');

Auth::routes();
Route::get('/dashboard', 'DashboardController@index');