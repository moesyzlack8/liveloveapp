<?php

namespace App\Http\Controllers;
use App\Http\Resources\UserResource;

use Illuminate\Http\Request;
//bring in user model
use App\User;

class DashboardController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        //get the users logged in ID
        $user_id = auth()->user()->id;
        $user = User::find($user_id);
        return view('dashboard')->with('posts', $user->posts);
    }
    
    public function getContacts(){
        return UserResource::collection(User::where('id', '!=', auth()->id())->get());//show all users except the end user thats logged in. return all users where id is not equal to the auth id then if its true get the user details. 
    }
}
