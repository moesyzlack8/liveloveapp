<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

use App\Models\Session;



class UserResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [ // passes the below data into the DashboardController
            'id'=> $this->id,
            'name'=> $this->name,
            'email' => $this->email,
            'online' => false,
            'session' => $this->session_details($this->id)//pulls session_details private function and passes the id
        ];
    }

    private function session_details($id)// accepts the individual id of the user thats been clicked on
    //check the session of users so that weather user1 and user2 is either logged in or clicked on if true get the first one, so theres always a session between the logged in user and the clicked user
    //wrapped session in new SessionResource
    {
        $session = Session::whereIn('user1_id', [auth()->id(), $id])->whereIn('user2_id',[auth()->id(), $id])->first();
        return new SessionResource($session);
    }
}
