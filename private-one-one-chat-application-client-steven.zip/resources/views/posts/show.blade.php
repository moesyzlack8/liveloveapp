@extends('layouts.app')

@section('content')
<div id="showPosts-page">
<a href="/posts" class="btn btn-warning">Go Back</a>
    <h1>{{$post->title}}</h1> <!--gets the title of the post when clicked-->
    <img style="width:100%" src="/storage/post_images/{{$post->post_image}}"><!--SHOWS THE IMAGE THE USER POSTED-->
    <br><br>
    <div>
        {!!$post->body!!}<!--puts the body in, parses the HTML-->
    </div>
    <hr>
    <small>Posted on {{$post->created_at}} by {{$post->user->name}}</small><!--shows when it was posted-->
    <hr>
    @if(!Auth::guest())<!--IF THE USER IS NOT A GUEST THEN SHOW THESE BUTTONS-->
        @if(Auth::user()->id ==$post->user_id)<!--ONLY EDIT AND DELETE YOUR OWN POSTS-->
            <a href="/posts/{{$post->id}}/edit" class="btn btn-success">Edit</a>
            <br>
            <br>
            {!!Form::open(['action' => ['PostsController@destroy', $post->id], 'method' => 'POST', 'class' => 'pull-right'])!!}
                {{Form::hidden('_method', 'DELETE')}}
                {{Form::submit('Delete', ['class' => 'btn btn-danger'])}}
            {!!Form::close() !!}
        @endif
    @endif
</div><!--showPosts-page end-->
@endsection